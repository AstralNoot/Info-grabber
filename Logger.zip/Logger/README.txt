Use Logger.bat if you want info collected to be sent to a webhook.

Use LoggerOffline.bat if you want a larger amount of info data to be dumped to a txt.

I am not responsible for any damages or harm caused by this program.

---------------------------------------------------------------------------------

MAKE SURE YOU REPLACE THE DISCORD WEBHOOK PLACEHOLDER IN THE LOGGER WITH YOUR OWN